# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate labels original text with physical files.

$key = q/secrecind/;
$external_labels{$key} = 'node11.html'; 
$key = q/secothers/;
$external_labels{$key} = 'node12.html'; 
$key = q/secfunctionals/;
$external_labels{$key} = 'node5.html'; 
$key = q/secrecursive/;
$external_labels{$key} = 'node8.html'; 
$key = q/secnoncomp/;
$external_labels{$key} = 'node6.html'; 
$key = q/seccbf/;
$external_labels{$key} = 'node3.html'; 
$key = q/secintro/;
$external_labels{$key} = 'node1.html'; 
$key = q/seclogic/;
$external_labels{$key} = 'node14.html'; 
$key = q/figbasis1/;
$external_labels{$key} = 'node3.html'; 
$key = q/secambig/;
$external_labels{$key} = 'node7.html'; 
$key = q/secformal/;
$external_labels{$key} = 'node10.html'; 
$key = q/secrecfun/;
$external_labels{$key} = 'node4.html'; 
$key = q/recursivefns/;
$external_labels{$key} = 'node13.html'; 
$key = q/secmtc/;
$external_labels{$key} = 'node15.html'; 

1;

