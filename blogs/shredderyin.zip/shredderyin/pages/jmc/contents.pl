# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate contents original text with physical files.

$key = q/0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '0%:%basis1.html%:%A BASIS FOR A MATHEMATICAL THEORY OF COMPUTATION ' unless ($toc_section_info{$key}); 
$key = q/0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node1.html%:%Introduction' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node2.html%:%Formalisms For Describing Computable Functions and Related Entities' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node3.html%:%Functions Computable in Terms of Given Base Functions ' unless ($toc_section_info{$key}); 
$key = q/0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node9.html%:%Properties of Computable Functions' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node4.html%:%Recursive Functions of the Integers' unless ($toc_section_info{$key}); 
$key = q/0 0 0 3 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node10.html%:%Formal Properties of Conditional Forms' unless ($toc_section_info{$key}); 
$key = q/0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node12.html%:%Relation to Other Formalisms' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node5.html%:%Computable Functionals' unless ($toc_section_info{$key}); 
$key = q/0 0 0 3 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node11.html%:%Recursion Induction' unless ($toc_section_info{$key}); 
$key = q/0 0 0 4 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node13.html%:%Recursive function theory' unless ($toc_section_info{$key}); 
$key = q/0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node15.html%:%Conclusion: Mathematical Theory of Computation' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node6.html%:%Non-Computable Functions and Functionals' unless ($toc_section_info{$key}); 
$key = q/0 0 0 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node14.html%:%On the Relations between Computation and Mathematical
  Logic' unless ($toc_section_info{$key}); 
$key = q/0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node16.html%:%REFERENCES' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node7.html%:%Ambiguous Functions' unless ($toc_section_info{$key}); 
$key = q/0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '3%:%node17.html%:%  About this document ... ' unless ($toc_section_info{$key}); 
$key = q/0 0 0 2 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0/;
$toc_section_info{$key} = '4%:%node8.html%:%Recursive Definitions of Sets' unless ($toc_section_info{$key}); 

1;

