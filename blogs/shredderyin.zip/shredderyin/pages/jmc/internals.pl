# LaTeX2HTML 96.1 (Feb 5, 1996)
# Associate internals original text with physical files.

$key = q/secrecind/;
$ref_files{$key} = 'node11.html'; 
$key = q/secothers/;
$ref_files{$key} = 'node12.html'; 
$key = q/secfunctionals/;
$ref_files{$key} = 'node5.html'; 
$key = q/secrecursive/;
$ref_files{$key} = 'node8.html'; 
$key = q/secnoncomp/;
$ref_files{$key} = 'node6.html'; 
$key = q/seccbf/;
$ref_files{$key} = 'node3.html'; 
$key = q/secintro/;
$ref_files{$key} = 'node1.html'; 
$key = q/seclogic/;
$ref_files{$key} = 'node14.html'; 
$key = q/figbasis1/;
$ref_files{$key} = 'node3.html'; 
$key = q/secambig/;
$ref_files{$key} = 'node7.html'; 
$key = q/secformal/;
$ref_files{$key} = 'node10.html'; 
$key = q/secrecfun/;
$ref_files{$key} = 'node4.html'; 
$key = q/recursivefns/;
$ref_files{$key} = 'node13.html'; 
$key = q/secmtc/;
$ref_files{$key} = 'node15.html'; 

1;

